const recipeData = require('./recipes');
const userData = require('./users');

// not much to do here
module.exports = {
  recipes: recipeData,
  users: userData
};