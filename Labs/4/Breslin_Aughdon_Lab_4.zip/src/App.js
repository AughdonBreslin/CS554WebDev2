import logo from './logo.svg';
import './App.css';
import { NavLink, BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import components
import Home from './components/Home';
import Events from './components/Events';
import Event from './components/Event';
import Attractions from './components/Attractions';
import Attraction from './components/Attraction';
import Venues from './components/Venues';
import Venue from './components/Venue';


function App() {

  return (
    <div className="App">
      <Router>
        <header className="App-header">
          <h1 className="App-title">Ticketmaster API</h1>
          <nav>
            <NavLink className='navlink' to='/'>
              Home
            </NavLink>
            <NavLink className='navlink' to='/events/page/1'>
              Events
            </NavLink>
            <NavLink className='navlink' to='/attractions/page/1'>
              Attractions
            </NavLink>
            <NavLink className='navlink' to='/venues/page/1'>
              Venues
            </NavLink>
          </nav>
        </header>

        <Routes>
          <Route exact path="/" element={<Home/>}/>
          <Route exact path="/events/page/:page" element={<Events/>}/>
          <Route exact path="/events/:id" element={<Event/>}/>
          <Route exact path="/attractions/page/:page" element={<Attractions/>}/>
          <Route exact path="/attractions/:id" element ={<Attraction/>}/>
          <Route exact path="/venues/page/:page" element={<Venues/>}/>
          <Route exact path="/venues/:id" element={<Venue/>}/>
          <Route path="/404" element={<h1>Error 404: Page not found.</h1>}/>
          <Route path="*" element={
            <div>
              <h1 className="info">Error 601: Invalid location specified.</h1>
              <p className="info">Please navigate to '/', '/events/page/:page', '/events/:id', '/attractions/page/:page', '/attractions/:id', '/venues/page/:page', or '/venues/:id'.</p>
            </div>
          }/>
        </Routes>
      </Router>
      <footer>
        <p>Aughdon Breslin 10447694</p>
      </footer>
    </div>
  );
}

export default App;
